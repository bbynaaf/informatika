# PREDIKSI KELULUSAN SNBP

A Pen created on CodePen.

Original URL: [https://codepen.io/Bunga-Syawalia-Fadiah/pen/QwWNjMM](https://codepen.io/Bunga-Syawalia-Fadiah/pen/QwWNjMM).

Prediksi Kelulusan SNBP adalah aplikasi web sederhana yang membantu memperkirakan peluang kelulusan SNBP. Masukkan data nilai dan lihat hasilnya secara instan! 🎯

🔗 Hitung rata-rata rapor di sini: (..)